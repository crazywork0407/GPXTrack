module.exports = {
    dir : __dirname,
    BASEURL : __dirname + "/assets"
}
